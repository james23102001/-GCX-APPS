***********************************************************************
********************  GC MANAGER 1.3  **************************
***********************************************************************


**Nouveautés :
	- L'option icône fonctionne maintenant. Cliquez sur icône, puis sélectionnez un
fichier .exe, puis sélectionnez un fichier .ico. Un nouveau fichier .exe portant l'icône choisi 
sera créé dans le même dossier que le premier.
	- GC Manager est désormais multi-lingues. Pour changer de langue, cliquez sur 
paramètres, et une fois que le fichier s'ouvre, changez le langage à Francais ou English 
selon la langue de votre choix.

Installation : Exécutez install.bat et attendez un bref instant. Vérifiez
ensuite si l'installation s'est bien passée. ( Le programme sera placé dans
C:/GC et un raccourci mis sur le bureau )

Les options :

Nouveau : Permet de créer un projet. Spéifiez le nom de votre projet et 
le coeur à utiliser, puis validez.

Ouvrir : Ouvrez le fichier home.ch d'un projet.

Exporter en standalone : Crée un fichier .exe distribuable. Sur le coeur 
tk, changer le nom de l'exécutable peut créer des problèmes.

Exporter en projet GC : Crée un fichier .gcx installable.

Installer : Sélectionnez un fichier .gcx, et le programme sera installé 
dans GC_Launcher. Cela marche aussi si vous faites clic-droit sur un 
fichier .gcx, puis ouvrir avec GC_Manager.

Paramètres : Ceci ouvrira le fichier de Configurations. Ne touchez à rien, 
sauf ( éventuellement ) au chemin des projets par défaut.

Déboguer : Ceci déboguera votre projet en cours.

Ouvrir : Ouvrir le dossier du projet va simplement ... Ouvrir le dossier du projet.

Icones : Ajoute des icônes à des fichiers .exe

Plug-ins est une option qui sera ajoutée plus tard.


GAME CENTER BURKINA, 74912162
James LILIOU