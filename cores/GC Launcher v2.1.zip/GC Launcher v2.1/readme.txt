**********************************************************************************************
***************************************Readme.txt*********************************************

App: GC Launcher
Version: 2
Autor: James LILIOU, GC admin

***Roles:
A new Launcher for GC apps

***Requirements:
- Ce programme ne marchera pas sans GC Builder.

***Message:
Pour l'installer, exécutez juste le fichier install.bat
Vous pouvez l'utiliser comme l'ancien, c'est pratiquement pareil. Les actions supportées :
- Lancer un programme
- Créer des racourcis
- Télécharger des programmes GC
Et bien d'autres.
	Donnez-nous votre avis!

***References:
GAME CENTER BURKINA
Facebook : GAME CENTER
Whartsapp : (+226) 74912162
Orange Money : (+226) 74912162